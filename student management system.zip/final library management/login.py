from tkinter import* 
from tkinter import messagebox
from tkinter import PhotoImage

def window():
    if usernameEntry.get()=='' or passwordEntry.get()=='':
          messagebox.showerror('error','Fields cannot be Empty')
    elif usernameEntry.get()=='Ramsy' and passwordEntry.get()=='1234':
        messagebox.showinfo('success','Welcome')
        login.destroy()
        import sms
    else: 
        messagebox.showerror('Error','Please enter correct credentials')

login = Tk()
login.geometry('1000x750+0+0')
login.title('login system of a student management syatem')
background_image = PhotoImage(file=r"C:\Users\x260\Pictures\library.png")
background_label = Label(login, image=background_image)
background_label.place(relwidth=1, relheight=1)
loginFrame=Frame(login,bg='white') 
loginFrame.place(x=400,y=150)

logoImage=PhotoImage(file=r"C:\Users\x260\Pictures\books.png" )
logoLabel=Label(loginFrame,image=logoImage)
logoLabel.grid(row=0,column=0,columnspan=2,pady=10)

usernameImage=PhotoImage(file=r"C:\Users\x260\Pictures\user.png")
usernamelabel=Label(loginFrame,image=usernameImage,text='username', compound=LEFT,font=('times new roman',20,'bold'),bg='white')
usernamelabel.grid(row=1,column=0,pady=10,padx=20)
usernameEntry=Entry(loginFrame,font=('times new roman',20,'bold'),bd=5,fg='royalblue')
usernameEntry.grid(row=1,column=1,pady=10,padx=20)

passwordImage=PhotoImage(file=r"C:\Users\x260\Pictures\eye.png")
passwordlabel=Label(loginFrame,image=usernameImage,text='Password', compound=LEFT,font=('times new roman',20,'bold'),bg='white')
passwordlabel.grid(row=2,column=0,pady=10,padx=20)
passwordEntry=Entry(loginFrame,font=('times new roman',20,'bold'),bd=5,fg='royalblue')
passwordEntry.grid(row=2,column=1,pady=10,padx=20)

loginButton=Button(loginFrame,text='Login',font=('times new roman',14,'bold'),width=15,fg='white',bg='cornflowerblue',activebackground='white',cursor='hand2',command=window)
loginButton.grid(row=3,column=1,pady=10)
login.mainloop()
